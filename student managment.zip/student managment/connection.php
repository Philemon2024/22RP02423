<?php
$servername="localhost";
$username="root";
$password="";
$dbname="class";
$con=mysqli_connect("localhost","root","","class");
?>