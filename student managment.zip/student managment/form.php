<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
</head>
<body>
    <fieldset style="width: 300px;background-color: pink">
    <form action="insert.php" method="POST">
        <center>
            <h1>Registration Form</h1>
            <table>
                <tr>
                    <td>Tel</td>
                    <td><input type="number" name="tel" required></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email" required></td>
                </tr>
                <tr>
                    <td>Age</td>
                    <td><input type="number" name="age" required></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>
                        <select name="gender" required>
                            <option value="M">M</option>
                            <option value="F">F</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Comment</td>
                    <td><input type="text" name="comment"></td>
                </tr>
                <tr>
                    <td>File</td>
                    <td><input type="file" name="file"></td>
                </tr>
                <tr>
                    <td>Image</td>
                    <td><input type="file" name="image"></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <input type="submit" name="send" value="Submit"><input type="reset" name="ssubmit" value="clear">
                    </td>
                </tr>
            </table>
        </center>
    </form>
    </fieldset>
</body>
</html>
